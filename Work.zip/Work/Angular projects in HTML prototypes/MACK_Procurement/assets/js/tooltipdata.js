var tooltip = [
    {
        tooltipid: 1, 
        title: "Request",
        in_progress: 05, on_hold: 28, rejected: 12, withdrawn: 7, completed: 14,
    },
    {
        tooltipid: 1, 
        title: "Request",
        in_progress: 05, on_hold: 28, rejected: 12, withdrawn: 7, completed: 14,
    },
    {
        tooltipid: 1, 
        title: "Request",
        in_progress: 05, on_hold: 28, rejected: 12, withdrawn: 7, completed: 14,
    },
    {
        tooltipid: 1, 
        title: "Request",
        in_progress: 05, on_hold: 28, rejected: 12, withdrawn: 7, completed: 14,
    },
    {
        tooltipid: 1, 
        title: "Request",
        in_progress: 05, on_hold: 28, rejected: 12, withdrawn: 7, completed: 14,
    },
    {
        tooltipid: 1, 
        title: "Request",
        in_progress: 05, on_hold: 28, rejected: 12, withdrawn: 7, completed: 14,
    },
    {
        tooltipid: 1, 
        title: "Request",
        in_progress: 05, on_hold: 28, rejected: 12, withdrawn: 7, completed: 14,
    },
    {
        tooltipid: 1, 
        title: "Request",
        in_progress: 05, on_hold: 28, rejected: 12, withdrawn: 7, completed: 14,
    }
];
